angular
    .module('meanGames')
    .controller('GamesController', GamesController);
function GamesController(GamesDataFactory){
    const vm = this;
    vm.title = 'MEAN Games App';
    GamesDataFactory
        .getAllGames()
        .then(function(res){
            vm.list = res;
            console.log(res);
        });
    vm.addGame = function(){
        console.log('Hello');
        const postData = {
            title: vm.newGameTitle,
            price: vm.newGamePrice,
            rate: vm.newGameRating,
            year: vm.newGameYear,
            rating: vm.newGameRating, 
            minPlayers: vm.newGameMinPlayers, 
            maxPlayers: vm.newGameMaxPlayers, 
            minAge: vm.newGameMinAge
        }
       
        if(vm.gameForm.$valid){
            console.log('postData');
            GamesDataFactory.postGame('/api/games', postData)
                .then(function(response){
                    console.log('Game Saved', response);
                })
                .catch(function(err){
                    console.log(err);
                })
        }
        else{
            vm.isSubmitted;
        }
    }
}