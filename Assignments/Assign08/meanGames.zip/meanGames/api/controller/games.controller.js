require('../data/db');
const mongoose = require('mongoose');

const Game = mongoose.model('Game');

const getGames = function(req, res) {
    console.log('Get Specified number of games request');
    let offset = 0;
    let count = 5;

    if(req.query.count && req.query.offset){
        console.log(req.query);

        if(isNaN(parseInt(req.query.offset)) || isNaN(parseInt(req.query.count))){
            res.status(200).send('Offset and Count must be numbers.');
            return;
        }
        else{
            offset = parseInt(req.query.offset) < 0 ? 0 : parseInt(req.query.offset);
            count = parseInt(req.query.count) < 1 ? 5 : parseInt(req.query.count);
        }
    }

    Game.find().skip(offset).limit(count).exec(function(err, games){
        if (err) {
            res.status(200).send('Error Retrieving data');
        } else {
            res.status(200).json(games);
        }
    });
}

const getOneGame = function(req, res) {
    console.log('Get One game request');
    const gameId = req.params.gameId;
    if(!mongoose.Types.ObjectId.isValid(gameId)){
        res.status(200).send('Not a valid Game Id');
        return;
    }
    Game.findById(gameId).exec(function(err, game){
        if (err) {
            console.log('Error Occured', err);
            res.status(200).send('Internal Error Occurred.');
        } else if(!game){
            res.status(404).send('Game ID not found in the system.');
        }else{
            res.status(200).json(game);
        }
    })
}

const addGame = function(req, res) {
    console.log('Add Game Request');
    console.log(req);
    const newGame = new Game(req.body);
    console.log(newGame);
    Game.create(newGame, function(err, resp){
        if (err) {
            console.log('Error Occurred', err);
            res.status(200).json('Failed to add a game to database.')
        } else {
            res.status(201).json('Game Added Succesfully');
        }
    })
}

const modifyGame = function(req, res){
    console.log('Modify Game Request');
    const gameId = req.params.gameId;
    const updateData = req.query;
    if(!mongoose.Types.ObjectId.isValid(gameId)){
        res.status(200).send('Not a valid Game ID');
        return;
    }
    Game.findById(gameId).exec(function(err, game){
        if(err){
            console.log('Failed to get a game', err);
            res.status(400).send('Error Occurred during modifying a game.');
        }
        else{
            Object.keys(updateData).forEach(function(key){
                game[key] = updateData[key];
            });
            game.save(function(err, updatedGame){
                if(err){
                    console.log(err);
                    res.status(500).send(err.message);
                }
                else{
                    res.status(200).json(updatedGame);
                }
            });
        }
    });
}

const replaceGame = function(req, res){
    console.log('Replace Game Request');
    const gameId = req.params.gameId;
    if(!mongoose.Types.ObjectId.isValid(gameId)){
        res.status(200).send(gameId + ' is not a valid Game ID');
        return;
    }
    Game.findById(gameId).select('_id').exec(function(err, game){
        if(err){
            console.log(err);
            res.status(200).send('Error getting game data');
        }
        else{
            console.log(game);
            Object.keys(req.query).forEach(function(key){
                game[key] = req.query[key];
            })
            game.save(function(err, response){
                if(err){
                    console.log(err)
                    res.status(200).send('Error Occurred during game replace.');
                }
                else{
                    res.status(200).send(response)
                }
            });
        }
    })
}

const deleteGame = function(req, res){
    console.log('Delete Game Request');
    const gameId = req.params.gameId;
    if(!mongoose.Types.ObjectId.isValid(gameId)){
        res.status(200)
            .send(gameId + ' is not a valid Game ID');
    }
    Game.findByIdAndDelete(gameId, function(err, response){
        if(err){
            console.log(err);
            res.status(200)
                .send('Error Occurred deleting a game');
        }else if(!response){
            res.status(404)
                .send('Game ID not found in the system.');
        }else{
            res.status(200)
                .json({
                    message: 'Game Deleted from System.',
                    gameData: response
                });
        }
    })

}

module.exports = {
    getGames: getGames,
    getOne: getOneGame,
    addGame: addGame,
    modifyGame: modifyGame,
    replaceGame: replaceGame,
    deleteGame: deleteGame
}